package com.interaction.link.model;

public class Participant {
}
