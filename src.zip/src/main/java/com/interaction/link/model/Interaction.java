package com.interaction.link.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "interactions")
public class Interaction {
    @Id
    private String id;
    private String name;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private int internalParticipants;
    private int externalParticipants;

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public int getInternalParticipants() {
        return internalParticipants;
    }

    public void setInternalParticipants(int internalParticipants) {
        this.internalParticipants = internalParticipants;
    }

    public int getExternalParticipants() {
        return externalParticipants;
    }

    public void setExternalParticipants(int externalParticipants) {
        this.externalParticipants = externalParticipants;
    }
}
