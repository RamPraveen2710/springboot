package com.interaction.link.repository;

import com.interaction.link.model.Interaction;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InteractionRepository extends MongoRepository<Interaction, String> {
}
