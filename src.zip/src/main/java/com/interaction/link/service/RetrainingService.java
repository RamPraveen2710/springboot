package com.interaction.link.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class RetrainingService {

    private final ModelLoader modelLoader;

    public RetrainingService(ModelLoader modelLoader) {
        this.modelLoader = modelLoader;
    }

    public boolean isRetrainingRequired() {
        try {
            long lineCount = Files.lines(Paths.get("src/main/resources/dataset/new_features.csv")).count();
            return lineCount > 10; // Retrain when more than 10 rows are present
        } catch (Exception e) {
            throw new RuntimeException("Error checking retraining requirement", e);
        }
    }

    public void retrainModel() {
        try {
            // Append features to original dataset
            appendFeaturesToOriginalDataset();

            // Execute the Python script for retraining
            ProcessBuilder processBuilder = new ProcessBuilder("D:/spring/link/venv/Scripts/python", "src/main/resources/scripts/retrain_model.py");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            process.waitFor();

            // Reload the model after retraining
            modelLoader.reloadModel();
            System.out.println("Model reloaded successfully after retraining.");
        } catch (Exception e) {
            throw new RuntimeException("Error during model retraining", e);
        }
    }

    private void appendFeaturesToOriginalDataset() throws Exception {
        String originalDatasetPath = "src/main/resources/dataset/original_dataset.csv";
        String newFeaturesPath = "src/main/resources/dataset/new_features.csv";

        // Read new features
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(newFeaturesPath));
             FileWriter writer = new FileWriter(originalDatasetPath, true)) {

            String line;
            while ((line = reader.readLine()) != null) {
                // Skip invalid or improperly formatted lines
                String[] fields = line.split(",");
                if (fields.length == 4) { // Ensure exactly 4 fields (time_diff, internal_match, external_match, label)
                    writer.write(line + "\n"); // Append new line for each entry
                } else {
                    System.err.println("Skipping improperly formatted line: " + line);
                }
            }

            // Clear the new_features.csv file after appending
//            Files.write(Paths.get(newFeaturesPath), new byte[0]);
        }
    }

}
