package com.interaction.link.service;

import com.interaction.link.model.Interaction;
import java.util.List;

public class ProcessResult {
    private String message;
    private List<ScoredInteraction> topInteractions;

    public ProcessResult(String message, List<ScoredInteraction> topInteractions) {
        this.message = message;
        this.topInteractions = topInteractions;
    }

    public String getMessage() {
        return message;
    }

    public List<ScoredInteraction> getTopInteractions() {
        return topInteractions;
    }
}
