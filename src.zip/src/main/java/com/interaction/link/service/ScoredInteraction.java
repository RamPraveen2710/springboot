package com.interaction.link.service;

import com.interaction.link.model.Interaction;

import java.util.List;

public class ScoredInteraction {
    private Interaction interaction;
    private double score;
    private List<Double> features;

    public ScoredInteraction(Interaction interaction, double score, List<Double> features) {
        this.interaction = interaction;
        this.score = score;
        this.features = features;
    }

    public Interaction getInteraction() {
        return interaction;
    }

    public void setInteraction(Interaction interaction) {
        this.interaction = interaction;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public List<Double> getFeatures() {
        return features;
    }

    public void setFeatures(List<Double> features) {
        this.features = features;
    }
}
