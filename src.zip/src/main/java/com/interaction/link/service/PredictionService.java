package com.interaction.link.service;

import com.interaction.link.model.Interaction;
import com.interaction.link.repository.InteractionRepository;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

@Service
public class PredictionService {

    private final InteractionRepository repository;
    private final ModelLoader modelLoader;
    private final RetrainingService retrainingService;

    public PredictionService(InteractionRepository repository, ModelLoader modelLoader, RetrainingService retrainingService) {
        this.repository = repository;
        this.modelLoader = modelLoader;
        this.retrainingService = retrainingService;
    }

    public List<Interaction> getAllInteractions() {
        // Retrieves all interactions from the database
        return repository.findAll();
    }

    public ProcessResult processAndInsertInteraction(Interaction newInteraction) throws Exception {
        List<Interaction> allInteractions = repository.findAll();

        // Process and predict logic
        List<ScoredInteraction> scoredInteractions = allInteractions.stream()
                .map(existingInteraction -> {
                    try {
                        // Calculate features and predict probability
                        List<Double> features = FeatureExtractor.extractFeatures(newInteraction, existingInteraction);
                        double probability = modelLoader.predict(features);
                        return new ScoredInteraction(existingInteraction, probability, features);
                    } catch (Exception e) {
                        throw new RuntimeException("Error predicting probability", e);
                    }
                })
                .sorted((a, b) -> Double.compare(b.getScore(), a.getScore()))
                .limit(5)
                .toList();

        // Logic for inserting new interaction if no match exceeds 50% probability
        double maxProbability = scoredInteractions.stream()
                .mapToDouble(ScoredInteraction::getScore)
                .max()
                .orElse(0.0);

        if (maxProbability < 0.9) {
            repository.save(newInteraction);

            // Append features to temporary dataset
            storeFeaturesForRetraining(scoredInteractions,newInteraction);

            // Trigger retraining if required
            if (retrainingService.isRetrainingRequired()) {
                retrainingService.retrainModel();
            }

            return new ProcessResult("New interaction inserted successfully.", scoredInteractions);
        } else {
            return new ProcessResult("New interaction not inserted due to high matching probability.", scoredInteractions);
        }
    }

//    private void storeFeaturesForRetraining(Interaction newInteraction, List<ScoredInteraction> scoredInteractions) {
//        try (BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/dataset/new_features.csv", true))) {
//            for (ScoredInteraction scoredInteraction : scoredInteractions) {
//                List<Double> features = scoredInteraction.getFeatures();
//                String csvLine = String.format("%s,%.2f,%.2f,%.2f,%.2f%n",
//                        newInteraction.getId(), features.get(0), features.get(1), features.get(2), scoredInteraction.getScore());
//                writer.write(csvLine);
//            }
//        } catch (Exception e) {
//            throw new RuntimeException("Error storing features for retraining", e);
//        }
//    }
    private void storeFeaturesForRetraining(List<ScoredInteraction> scoredInteractions, Interaction newInteraction) {
        String newFeaturesPath = "src/main/resources/dataset/new_features.csv";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(newFeaturesPath, true))) {
            // Write the header if the file is empty
            File file = new File(newFeaturesPath);
            if (file.length() == 0) {
                writer.write("f0,f1,f2,target\n");
            }

            // Append features and labels
            for (ScoredInteraction interaction : scoredInteractions) {
                List<Double> features = interaction.getFeatures();
                String csvLine = String.format("%.4f,%.4f,%.4f,%.4f%n",
                        features.get(0), // f0
                        features.get(1), // f1
                        features.get(2), // f2
                        interaction.getScore()); // target
                writer.write(csvLine);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error writing to new_features.csv", e);
        }
    }

}
