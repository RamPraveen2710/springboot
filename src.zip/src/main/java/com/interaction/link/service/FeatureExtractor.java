package com.interaction.link.service;

import com.interaction.link.model.Interaction;

import java.time.temporal.ChronoUnit;
import java.util.List;

public class FeatureExtractor {

    public static List<Double> extractFeatures(Interaction newInteraction, Interaction existingInteraction) {
        validateInteraction(newInteraction);
        validateInteraction(existingInteraction);

        double timeDiff = calculateTimeDifference(newInteraction, existingInteraction); // f0
        double internalMatch = calculateInternalMatch(newInteraction, existingInteraction); // f1
        double externalMatch = calculateExternalMatch(newInteraction, existingInteraction); // f2

        return List.of(timeDiff, internalMatch, externalMatch);
    }

    private static double calculateTimeDifference(Interaction newInteraction, Interaction existingInteraction) {
        return Math.abs(ChronoUnit.MINUTES.between(existingInteraction.getStartTime(), newInteraction.getStartTime()));
    }

    private static double calculateInternalMatch(Interaction newInteraction, Interaction existingInteraction) {
        int newInternal = newInteraction.getInternalParticipants();
        int existingInternal = existingInteraction.getInternalParticipants();

        if (existingInternal == 0 || newInternal == 0) {
            return 0.0;
        }

        return Math.min(newInternal, existingInternal) / (double) Math.max(newInternal, existingInternal);
    }

    private static double calculateExternalMatch(Interaction newInteraction, Interaction existingInteraction) {
        int newExternal = newInteraction.getExternalParticipants();
        int existingExternal = existingInteraction.getExternalParticipants();

        if (existingExternal == 0 || newExternal == 0) {
            return 0.0;
        }

        return Math.min(newExternal, existingExternal) / (double) Math.max(newExternal, existingExternal);
    }

    private static void validateInteraction(Interaction interaction) {
        if (interaction.getStartTime() == null || interaction.getEndTime() == null) {
            throw new IllegalArgumentException("Start time or end time cannot be null.");
        }
        if (interaction.getInternalParticipants() < 0 || interaction.getExternalParticipants() < 0) {
            throw new IllegalArgumentException("Participant counts cannot be negative.");
        }
    }
}
