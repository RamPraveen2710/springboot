package com.interaction.link.service;

import ai.onnxruntime.*;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Component
public class ModelLoader {

    private final OrtEnvironment env;
    private OrtSession session;

    public ModelLoader() throws OrtException {
        env = OrtEnvironment.getEnvironment();
        reloadModel();
    }

    public void reloadModel() throws OrtException {
        if (session != null) {
            session.close();
        }
        OrtSession.SessionOptions options = new OrtSession.SessionOptions();
        session = env.createSession("src/main/resources/models/xgb_model.onnx", options);
    }

    public double predict(List<Double> features) throws OrtException {
        float[] inputArray = new float[features.size()];
        for (int i = 0; i < features.size(); i++) {
            inputArray[i] = features.get(i).floatValue();
        }
        float[][] input2DArray = {inputArray};
        OnnxTensor inputTensor = OnnxTensor.createTensor(env, input2DArray);
        OrtSession.Result result = session.run(Collections.singletonMap("float_input", inputTensor));
        float[][] predictions = (float[][]) result.get(0).getValue();
        return predictions[0][0];
    }
}
