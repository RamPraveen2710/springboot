package com.interaction.link.controller;

import com.interaction.link.model.Interaction;
import com.interaction.link.service.PredictionService;
import com.interaction.link.service.ProcessResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/predictions")
public class PredictionController {

    @Autowired
    private PredictionService predictionService;

    @GetMapping("/allInteractions")
    public List<Interaction> getAllInteractions() {
        // Fetches all interactions from the repository
        return predictionService.getAllInteractions();
    }

    @PostMapping("/processAndInsert")
    public ProcessResult processAndInsertInteraction(@RequestBody Interaction newInteraction) {
        try {
            // Processes the new interaction and inserts it based on logic
            return predictionService.processAndInsertInteraction(newInteraction);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error processing interaction", e);
        }
    }
}
