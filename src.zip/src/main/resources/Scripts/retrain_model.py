import pandas as pd
import xgboost as xgb
import onnxmltools
from skl2onnx.common.data_types import FloatTensorType

# Paths for datasets and model
original_dataset_path = "src/main/resources/dataset/original_dataset.csv"
new_features_path = "src/main/resources/dataset/new_features.csv"
updated_dataset_path = "src/main/resources/dataset/original_dataset.csv"
model_save_path = "src/main/resources/models/xgb_model.onnx"

# Load the original dataset
data = pd.read_csv(original_dataset_path)

# Load new features from the temporary storage
new_features = pd.read_csv(new_features_path, header=None)

# Assign proper column names to new_features
new_features.columns = ["f0", "f1", "f2", "target"]

# Ensure all columns are numeric
new_features = new_features.apply(pd.to_numeric, errors='coerce')
new_features = new_features.dropna()  # Drop rows with NaN values

# Append new features to the original dataset
updated_data = pd.concat([data, new_features], ignore_index=True)

# Save the updated dataset for future use
updated_data.to_csv(updated_dataset_path, index=False)
print(f"Updated dataset saved to {updated_dataset_path}")

# Ensure the feature columns are numeric
updated_data["f0"] = pd.to_numeric(updated_data["f0"], errors="coerce")
updated_data["f1"] = pd.to_numeric(updated_data["f1"], errors="coerce")
updated_data["f2"] = pd.to_numeric(updated_data["f2"], errors="coerce")
updated_data["target"] = pd.to_numeric(updated_data["target"], errors="coerce")

# Drop rows with NaN values after conversion
updated_data = updated_data.dropna()

# Define features (X) and target (y)
X = updated_data[["f0", "f1", "f2"]]
y = updated_data["target"]

# Train the XGBoost model
model = xgb.XGBRegressor()
model.fit(X, y)

# Define the input shape for ONNX conversion
initial_type = [("float_input", FloatTensorType([None, X.shape[1]]))]

try:
    # Convert the XGBoost model to ONNX using onnxmltools
    onnx_model = onnxmltools.convert_xgboost(model, initial_types=initial_type)

    # Save the ONNX model
    with open(model_save_path, "wb") as f:
        f.write(onnx_model.SerializeToString())
    print(f"Model retrained and saved as {model_save_path}")

except Exception as e:
    print(f"Error during ONNX conversion: {e}")
